﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Google.Protobuf.WellKnownTypes;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace DBBase
{
    public partial class Form1 : Form
    {
        #region 초기값
        private string _server = "localhost";
        private string _database = "test";
        private string _port = "3306";
        private string _uid = "root";
        private string _pass = "1234";
        string Conn = "";
        public Form1()
        {
            InitializeComponent();
            ls_view.View = View.Details;
            Conn = string.Format("Server={0};Port={1};Database={2};Uid={3};Pwd={4}", _server, _port, _database, _uid, _pass);
            DBopenview();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        #endregion
        #region dbset
        private void DBopenview()
        {
            try
            {   
                // using으로 때린 이유는 close를 처리를 안해도되기때문에 
                using (MySqlConnection mysql = new MySqlConnection(Conn))
                {
                    mysql.Open();
                    string SelectQuery = "SELECT * from dbk";
                    MySqlCommand command = new MySqlCommand(SelectQuery,mysql);
                    MySqlDataReader reader = command.ExecuteReader();
                    ListViewItem lvi = new ListViewItem();

                    while(reader.Read())
                    {
                        this.ls_view.Items.Add(new ListViewItem(new String[] { reader[1].ToString(), reader[2].ToString(), reader[3].ToString() }));
                    }
                }

            }catch (Exception ex) 
            {
                MessageBox.Show("에러발생");
            }
        }
        #endregion
        #region 삽입
        private void btn_insert_Click(object sender, EventArgs e) //완료임 
        {
            try
            {
                using(MySqlConnection mysql = new MySqlConnection(Conn))
                {
                    mysql.Open();
                    string InsertQuery = "INSERT INTO dbk(name, phone, job)";
                    InsertQuery += "VALUES('" + this.txt_name.Text + "','" + this.txt_phonenum.Text + "','" + this.txt_job.Text + "')";
                    MySqlCommand command = new MySqlCommand(InsertQuery,mysql);
                    command.ExecuteNonQuery();
                    if(command.ExecuteNonQuery() == 1)
                    {
                        MessageBox.Show("정상적으로 업데이트가 완료되었습니다", "알림", MessageBoxButtons.OK);
                    }
                    else
                    {
                        MessageBox.Show("에러발생", "알림", MessageBoxButtons.OK);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("아니 에러그거지?");
            }
        }
        #endregion
        #region 삭제
        private void btn_delete_Click(object sender, EventArgs e) //완료임 
        {


            DialogResult _dlr = MessageBox.Show("데이터를 삭제합니까?", "알림", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            switch (_dlr)
            {
                case DialogResult.Yes:
                    try
                    {
                        using (MySqlConnection mysql = new MySqlConnection(Conn))
                        {
                            mysql.Open();
                            string deleteQurey = "DELETE from dbk where name = ";
                            deleteQurey += "'" + this.txt_name.Text + "'";
                            MySqlCommand command = new MySqlCommand(deleteQurey, mysql);
                            if (command.ExecuteNonQuery() != 1)
                            {
                                MessageBox.Show("성공적으로 삭제되었습니다", "알림", MessageBoxButtons.OK);
                            }
                            else
                            {
                                MessageBox.Show("정상적으로 삭제되지 않았습니다.", "에러", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("에러 발생" + ex);
                    }
                    break;
                case DialogResult.No:
                    break;
            }
        }
        #endregion
        #region 수정
        private void btn_update_Click(object sender, EventArgs e)
        {
            try
            {
                //this.lvlist_Click(); 클릭해서 업뎃할려했는데 아 지금 너무 ...
                using (MySqlConnection Mysql = new MySqlConnection(Conn))
                {
                    Mysql.Open();
                    //InsertQuery += "VALUES('" + this.txt_name.Text + "','" + this.txt_phonenum.Text + "','" + this.txt_job.Text + "')"; 
                    string UpdateQuery = "UPDATE dbk SET name ='"  + this.txt_name.Text + "',' phone=" + this.txt_phonenum.Text + ",' job = " + this.txt_job+ "'"  ; // 따옴표때문에 쿼리 에러가 날게뻔함 
                    //string UpdateQuery = "update dbk set name =" + "'" + this.txt_name + "'" + "phone = " + "'" + this.txt_phonenum + "'" + "job =" + "'" + this.txt_job + "'";       
                    // 역시나 발생했다 아 디비 쿼리가 제일 귀찮아서 싫어하는데 이게 맞다역시...
                    //UpdateQuery += "', name ='" + this.txt_name.Text + "', phone = '" + this.txt_phonenum.Text + "', job= '" + this.txt_job.Text + "'WHERE id = " + txt_name.Text + "";
                    MySqlCommand command = new MySqlCommand(UpdateQuery, Mysql);
                    if (command.ExecuteNonQuery() != 1)
                    {
                        MessageBox.Show("수정완료", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("수정실패", "알림", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("코드에러 :" +  ex);
            }

        }
        #endregion
        #region 검색
        private void btn_select_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection mysql = new MySqlConnection(Conn))
                {
                    mysql.Open();
                    string SelectQuery = "SELECT name from dbk  where name = " + "'" + txt_name.Text +"'";
                    //SelectQuery += "'"+ this.txt_name.Text + "'"; 이렇게 해도됩니다 근데 걍 한줄로 해서 가독성 높입시다
                    MySqlCommand command = new MySqlCommand(SelectQuery, mysql);

                    
                    if (command.ExecuteNonQuery() != 1)
                    {
                        MessageBox.Show("검색완료", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("검색실패", "알림", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("코드 에러발생 : " + ex);
            }
        }
        #endregion

    }
}

