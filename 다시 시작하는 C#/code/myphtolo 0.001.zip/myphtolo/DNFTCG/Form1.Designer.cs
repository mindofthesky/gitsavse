﻿namespace DNFTCG
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            my_monster_field = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            button20 = new Button();
            button21 = new Button();
            button22 = new Button();
            button23 = new Button();
            button24 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(72, 792);
            button1.Name = "button1";
            button1.Size = new Size(174, 233);
            button1.TabIndex = 0;
            button1.Text = "효과존";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(252, 792);
            button2.Name = "button2";
            button2.Size = new Size(174, 233);
            button2.TabIndex = 1;
            button2.Text = "효과존";
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(432, 792);
            button3.Name = "button3";
            button3.Size = new Size(174, 233);
            button3.TabIndex = 2;
            button3.Text = "효과존";
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(612, 792);
            button4.Name = "button4";
            button4.Size = new Size(174, 233);
            button4.TabIndex = 3;
            button4.Text = "레벨존";
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Location = new Point(792, 792);
            button5.Name = "button5";
            button5.Size = new Size(174, 233);
            button5.TabIndex = 4;
            button5.Text = "덱";
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Location = new Point(972, 792);
            button6.Name = "button6";
            button6.Size = new Size(174, 233);
            button6.TabIndex = 5;
            button6.Text = "묘지";
            button6.UseVisualStyleBackColor = true;
            // 
            // my_monster_field
            // 
            my_monster_field.Location = new Point(72, 553);
            my_monster_field.Name = "my_monster_field";
            my_monster_field.Size = new Size(174, 233);
            my_monster_field.TabIndex = 6;
            my_monster_field.Text = "몬스터존";
            my_monster_field.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.Location = new Point(252, 553);
            button8.Name = "button8";
            button8.Size = new Size(174, 233);
            button8.TabIndex = 7;
            button8.Text = "스킬";
            button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.Location = new Point(432, 555);
            button9.Name = "button9";
            button9.Size = new Size(174, 233);
            button9.TabIndex = 8;
            button9.Text = "스킬";
            button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.Location = new Point(612, 556);
            button10.Name = "button10";
            button10.Size = new Size(174, 233);
            button10.TabIndex = 9;
            button10.Text = "스킬";
            button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            button11.Location = new Point(792, 556);
            button11.Name = "button11";
            button11.Size = new Size(174, 233);
            button11.TabIndex = 10;
            button11.Text = "장비";
            button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            button12.Location = new Point(972, 556);
            button12.Name = "button12";
            button12.Size = new Size(174, 233);
            button12.TabIndex = 11;
            button12.Text = "장비";
            button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            button13.Location = new Point(972, 12);
            button13.Name = "button13";
            button13.Size = new Size(174, 233);
            button13.TabIndex = 23;
            button13.Text = "효과";
            button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            button14.Location = new Point(792, 12);
            button14.Name = "button14";
            button14.Size = new Size(174, 233);
            button14.TabIndex = 22;
            button14.Text = "효과";
            button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            button15.Location = new Point(612, 12);
            button15.Name = "button15";
            button15.Size = new Size(174, 233);
            button15.TabIndex = 21;
            button15.Text = "효과";
            button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            button16.Location = new Point(432, 11);
            button16.Name = "button16";
            button16.Size = new Size(174, 233);
            button16.TabIndex = 20;
            button16.Text = "레벨존";
            button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            button17.Location = new Point(252, 9);
            button17.Name = "button17";
            button17.Size = new Size(174, 233);
            button17.TabIndex = 19;
            button17.Text = "덱";
            button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            button18.Location = new Point(72, 9);
            button18.Name = "button18";
            button18.Size = new Size(174, 233);
            button18.TabIndex = 18;
            button18.Text = "묘지";
            button18.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            button19.Location = new Point(972, 248);
            button19.Name = "button19";
            button19.Size = new Size(174, 233);
            button19.TabIndex = 17;
            button19.Text = "몬스터존";
            button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            button20.Location = new Point(792, 248);
            button20.Name = "button20";
            button20.Size = new Size(174, 233);
            button20.TabIndex = 16;
            button20.Text = "스킬";
            button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            button21.Location = new Point(612, 248);
            button21.Name = "button21";
            button21.Size = new Size(174, 233);
            button21.TabIndex = 15;
            button21.Text = "스킬";
            button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            button22.Location = new Point(432, 248);
            button22.Name = "button22";
            button22.Size = new Size(174, 233);
            button22.TabIndex = 14;
            button22.Text = "스킬";
            button22.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            button23.Location = new Point(252, 248);
            button23.Name = "button23";
            button23.Size = new Size(174, 233);
            button23.TabIndex = 13;
            button23.Text = "장비";
            button23.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            button24.Location = new Point(72, 248);
            button24.Name = "button24";
            button24.Size = new Size(174, 233);
            button24.TabIndex = 12;
            button24.Text = "장비";
            button24.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1241, 1061);
            Controls.Add(button13);
            Controls.Add(button14);
            Controls.Add(button15);
            Controls.Add(button16);
            Controls.Add(button17);
            Controls.Add(button18);
            Controls.Add(button19);
            Controls.Add(button20);
            Controls.Add(button21);
            Controls.Add(button22);
            Controls.Add(button23);
            Controls.Add(button24);
            Controls.Add(button12);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(my_monster_field);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button my_monster_field;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
        private Button button21;
        private Button button22;
        private Button button23;
        private Button button24;
    }
}