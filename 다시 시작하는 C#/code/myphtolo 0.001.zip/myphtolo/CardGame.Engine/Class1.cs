﻿namespace CardGame.Engine
{
    public class Class1
    {

    }
}