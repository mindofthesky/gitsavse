﻿namespace CardGame.Base
{
    public class Class1
    {

    }
}